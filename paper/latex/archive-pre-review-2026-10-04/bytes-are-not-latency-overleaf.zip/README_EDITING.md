# 论文源文件编辑说明（Overleaf）

## Overleaf 设置
- Menu → Compiler：**pdfLaTeX**
- Menu → Main document：**arxiv.tex**。这是完整版，包括正文、参考文献和附录，日常修改都编译这个。
- 不要把 `paper.tex` 设成主文档。它是三个版本共用的源文件，单独编译出来的是匿名投稿正文，正文里指向附录的引用会显示成 "??"。

## 文件
| 文件 | 内容 | 能否修改 |
|---|---|---|
| `paper.tex` | 标题、摘要、第 1–6 节、致谢 | 可以，只改措辞 |
| `appendix.tex` | 附录 A、B 和 Figure A1 | 可以，只改措辞 |
| `references.bib` | 参考文献 | 先商量 |
| `arxiv.tex`、`submission.tex`、`submission_appendix.tex` | 三个版本的入口，里面只设开关 | 不要改 |
| `figures/` | 图，由脚本生成 | 不要改 |
| `mlsys2025.sty`、`mlsys2025.bst`、`fancyhdr.sty`、`algorithm*.sty` | MLSys 官方模板 | 不要改 |

## 修改规则
1. **只改措辞。** 数字、表格内容和结论都已经和实验数据核对过。如果需要改，先和论文负责人商量。
2. **一句一行。** 每个句子单独占一行，改一句就只动这一行。段落之间用空行隔开；除非确实要分段或合并段落，否则不要增删空行。
3. **以下宏不要删除，也不要改写：**
   - `\anon{...}`：投稿版里会被替换成 `[anonymized]` 的标识符；
   - `\anonurl{...}`：仓库链接；
   - `\appref{...}`：正文指向附录的引用；
   - `\ifarxiv ... \fi`：只在 arXiv 版出现的内容，例如致谢。
4. **正文不能超过 10 页。** 编译 `arxiv.tex` 后，第 6 节必须在第 10 页结束（现在在第 10 页左栏结束），措辞改长很容易超页。
5. **图要改需要重画**，不能直接改 `figures/` 里的 PDF。
6. 修改时尽量用 Overleaf 的评论和修订追踪（Track changes），方便审阅。

## 作者信息
arXiv 版的作者、单位和邮箱写在 `paper.tex` 开头的 `\AuthorName`、`\AuthorAffiliation`、`\AuthorEmail` 里，目前还是占位符。投稿版会自动显示为 "Anonymous Authors"。

## 定稿
投稿用的两个匿名 PDF（正文 `submission.pdf` 和附录 `submission_appendix.pdf`）不在 Overleaf 上编译。定稿时从 Overleaf 下载源文件（Menu → Download → Source），在本地用 `make` 生成，并做页数、匿名和数字核对。
